package com.example.itsdatamanage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "data_kuliah";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "data_mhs";  // Hapus spasi
    public static final String ID_COL = "id";
    public static final String NAME_COL = "nama_mhs";
    public static final String PHONE_COL = "no_telp";
    public static final String COURSE_COL = "mat_kul";
    public static final String SKS_COL = "sks";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "  // Tambahkan spasi setelah "id"
                + NAME_COL + " TEXT, "
                + PHONE_COL + " TEXT, "
                + COURSE_COL + " TEXT, "
                + SKS_COL + " TEXT)";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    // Pindahkan method ini ke luar onUpgrade
    public void addNewCourse(String mhsName, String mhsPhone, String mhsCourse, String mhsSKS) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, mhsName);
        values.put(PHONE_COL, mhsPhone);
        values.put(COURSE_COL, mhsCourse);
        values.put(SKS_COL, mhsSKS);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<dataMhs> ReadDataMhs() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorMhs = db.rawQuery("SELECT * FROM " + TABLE_NAME,null);
        ArrayList<dataMhs> dataMhsArrayList = new ArrayList<>();
        if (cursorMhs.moveToFirst()){
            do{
                dataMhsArrayList.add(new dataMhs(
                        cursorMhs.getString(1), cursorMhs.getString(4),
                        cursorMhs.getString(2), cursorMhs.getString(3)
                ));
            } while (cursorMhs.moveToNext());
        }

        cursorMhs.close();
        return dataMhsArrayList;
    }
}
