package com.example.itsdatamanage;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText etNama, etPhone, etCourse, etSKS;
    private Button btTambah;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNama = findViewById(R.id. et_name);
        etPhone = findViewById(R.id. et_phone);
        etCourse = findViewById(R.id.et_course);
        etSKS = findViewById(R.id.et_sks);
        btTambah = findViewById(R.id.bt_add_data);

        dbHelper = new DBHelper(MainActivity.this);
        btTambah.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.bt_add_data:
                String nama = etNama.getText().toString();
                String telp = etPhone.getText().toString();
                String matkul = etCourse.getText().toString();
                String sks = etSKS.getText().toString();

                if(nama.isEmpty() || telp.isEmpty() || matkul.isEmpty() || sks.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill the" + "blanks", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHelper.addNewCourse(nama, telp, matkul, sks);
                Toast.makeText(MainActivity.this, "Data Berhasil disimpan", Toast.LENGTH_SHORT).show();
                    etNama.setText("");
                    etPhone.setText("");
                    etCourse.setText("");
                    etSKS.setText("");
                    break;
                }
        }

}