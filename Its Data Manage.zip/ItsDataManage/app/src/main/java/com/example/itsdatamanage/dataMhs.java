package com.example.itsdatamanage;

public class dataMhs {
    private String nama;
    private String telp;
    private String matkul;
    private String sks;
    private int id;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTelp() {
        return telp;
    }

    public void setTelp(String telp) {
        this.telp = telp;
    }

    public String getMatkul() {
        return matkul;
    }

    public void setMatkul(String matkul) {
        this.matkul = matkul;
    }

    public String getSks() {
        return sks;
    }

    public void setSks(String sks) {
        this.sks = sks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public dataMhs(String nama, String telp, String matkul, String sks) {
        this.nama = nama;
        this.telp = telp;
        this.matkul = matkul;
        this.sks = sks;
    }
}
